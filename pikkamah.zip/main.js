document.addEventListener('DOMContentLoaded', function () {
    // ... existing code ...

    const scrollToTopButton = document.getElementById('scrollToTop');

    // Show or hide the scroll-to-top button based on the scroll position
    window.addEventListener('scroll', function () {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            scrollToTopButton.style.display = 'block';
        } else {
            scrollToTopButton.style.display = 'none';
        }
    });

    // Smooth scroll to the top when the button is clicked
    scrollToTopButton.addEventListener('click', function () {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });

          scrollToTopButton.style.animation = 'fadeIn 0.5s ease';
        setTimeout(() => {
            scrollToTopButton.style.animation = '';
        }, 500)
    });
});